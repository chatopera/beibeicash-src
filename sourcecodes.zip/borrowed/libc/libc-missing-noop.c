void gnc_libc_missing_noop (void);

void gnc_libc_missing_noop (void)
{
    return;
}
