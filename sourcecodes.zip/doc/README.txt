This directory contains manpages, the tip-of-the-day message
source, and a sample gtk-3.0.css to demonstrate how to customize
GnuCash's Graphical User Interface.

The example directory contains some basic files for
elementary testing and to illustrate the formats.
