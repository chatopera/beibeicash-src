/********************************************************************\
 * dialog-preferences.c -- preferences dialog                       *
 *                                                                  *
 * Copyright (C) 2024 Chatopera Inc. <info@chatopera.com>           *
 *                                                                  *
 * This program is free software; you can redistribute it and/or    *
 * modify it under the terms of the GNU General Public License as   *
 * published by the Free Software Foundation; either version 2 of   *
 * the License, or (at your option) any later version.              *
 *                                                                  *
 * This program is distributed in the hope that it will be useful,  *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of   *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    *
 * GNU General Public License for more details.                     *
 *                                                                  *
 * You should have received a copy of the GNU General Public License*
 * along with this program; if not, contact:                        *
 *                                                                  *
 * Free Software Foundation           Voice:  +1-617-542-5942       *
 * 51 Franklin Street, Fifth Floor    Fax:    +1-617-542-2652       *
 * Boston, MA  02110-1301,  USA       gnu@gnu.org                   *
\********************************************************************/

#include <config.h>

#include <stdlib.h>
#include <gtk/gtk.h>
#include <glib/gi18n.h>
#include <glib.h>

#include "dialog-utils.h"
#include <gnc-filepath-utils.h>
#include "dialog-licensemanagement.h"
#include "gnc-ui-util.h"

// Sent http requests
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>
#include <json.h>

/* This static indicates the debugging module that this .o belongs to.  */
static QofLogModule log_module = GNC_MOD_GUI;

/**
 * Utility functions for curl
 * https://stackoverflow.com/questions/2329571/c-libcurl-get-output-into-a-string
 */
struct curlRespBody
{
    char *ptr;
    size_t len;
};

typedef struct _License
{
    /* basic info*/
    GString *id;
    GString *status;
    int totalCapacity;
    int remainCapacity;
    GString *assignedOwner;
    GString *expiredDate;

    /* extras */
    GString *productShortId;
    GString *productName;
} License;

static void init_curl_resp_body(struct curlRespBody *s)
{
    s->len = 0;
    s->ptr = malloc(s->len + 1);
    if (s->ptr == NULL)
    {
        fprintf(stderr, "malloc() failed\n");
        exit(EXIT_FAILURE);
    }
    s->ptr[0] = '\0';
}

static size_t write_curl_resp_body(void *ptr, size_t size, size_t nmemb, struct curlRespBody *s)
{
    size_t new_len = s->len + size * nmemb;
    s->ptr = realloc(s->ptr, new_len + 1);
    if (s->ptr == NULL)
    {
        fprintf(stderr, "realloc() failed\n");
        exit(EXIT_FAILURE);
    }
    memcpy(s->ptr + s->len, ptr, size * nmemb);
    s->ptr[new_len] = '\0';
    s->len = new_len;

    return size * nmemb;
}

/**
 * Load config file, or init it if not exist.
 */
static gchar *init_subscription_conf()
{
    gchar *license_config_filename = g_build_filename(gnc_userconfig_dir(),
                                                      "subscription.conf", (char *)NULL);
    if (g_file_test(license_config_filename, G_FILE_TEST_EXISTS))
    {
        PINFO("[subscription] license_config_filename %s already exist", license_config_filename);

        /* Create a new GKeyFile object and a bitwise list of flags. */
        g_autoptr(GError) error = NULL;
        g_autoptr(GKeyFile) key_file = g_key_file_new();
        GKeyFileFlags flags;
        flags = G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS;

        if (!g_key_file_load_from_file(key_file, license_config_filename, flags, &error))
        {
            if (!g_error_matches(error, G_FILE_ERROR, G_FILE_ERROR_NOENT))
                PWARN("[subscription] Error loading key file: %s", error->message);

            PWARN("[subscription] exit: %s", "1");
            exit(1);
        }

        g_autofree gchar *val = g_key_file_get_string(key_file, "license", "licenseId", &error);
        if (val == NULL &&
            !g_error_matches(error, G_KEY_FILE_ERROR, G_KEY_FILE_ERROR_KEY_NOT_FOUND))
        {
            PWARN("[subscription] Error finding key in key file: %s", error->message);
            val = "";
        }
        else if (val == NULL)
        {
            // Fall back to a default value.
            PWARN("[subscription] Fall back to a default value");
            val = "";
        }

        g_free(license_config_filename);

        return val;
    }
    else
    {
        // init key file
        g_autoptr(GKeyFile) key_file = g_key_file_new();
        const gchar *val = "https://store.chatopera.com";
        g_autoptr(GError) error = NULL;

        // Just to avoid blank items, no usage for store as it is hardcode URL further
        g_key_file_set_string(key_file, "license", "store", val);

        // Save as a file.
        if (!g_key_file_save_to_file(key_file, license_config_filename, &error))
        {
            // throw an error and exit.
            PWARN("[subscription] Error saving key file: %s", error->message);
            PWARN("[subscription] exit: %s", "2");
            exit(2);
        }
        else
        {
            PINFO("[subscription] confg file inited with %s", license_config_filename);
        }

        g_free(license_config_filename);

        // set license as empty
        return "";
    }
}

/**
 * Request license info on Chatopera License Store
 */
static GString *get_subscription_info_on_store(const char *licenseId)
{
    CURL *curl;
    CURLcode res;

    // must concatenate before curl_global_init!!!
    GString *reqUrl = g_string_new("https://store.chatopera.com/api/quotawd/license/basics/");
    g_string_append(reqUrl, licenseId);

    /**
     * In Windows, this inits the Winsock stuff
     * mistery code, curl_global_init would cause licenseId concatenate error to other strings
     * must concatenate before curl_global_init!!!
     */
    curl_global_init(CURL_GLOBAL_ALL);

    curl = curl_easy_init();
    if (curl)
    {
        struct curlRespBody resp;
        init_curl_resp_body(&resp);

        /* Now, licenseId is messed up due to curl_global_init */
        PINFO("[subscription] Get req url %s, licenseId [%s]", reqUrl->str, licenseId);

        curl_easy_setopt(curl, CURLOPT_URL, reqUrl->str);
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_curl_resp_body);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resp);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);

        /* Perform the request, res gets the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if (res != CURLE_OK)
        {
            PINFO("[subscription] curl_easy_perform() failed: %s, app exit.",
                  curl_easy_strerror(res));
            // TODO error happens
            // provide notify and close app
            // Can not connect to internet?
            exit(3);
        }

        PINFO("[subscription] Get curl quotawd/license/basics response [%s]", resp.ptr);
        // licenseInfo = json_tokener_parse(resp.ptr);
        GString *licenseInfo = g_string_new(resp.ptr);

        /* always cleanup */
        g_free(resp.ptr);
        g_free(reqUrl);
        curl_easy_cleanup(curl);
        curl_global_cleanup();

        return licenseInfo;
    }

    return g_string_new("{}");
}

/**
 * Parse license properties from json object return from store.
 */
static void parse_license_with_jsonresponse(json_object *licenseInfo, License *license)
{
    struct json_object *rc, *data, *data0;
    int rc_val;

    json_object_object_get_ex(licenseInfo, "rc", &rc);
    rc_val = json_object_get_int(rc);

    if (rc_val == 0)
    {
        // extract data
        json_object_object_get_ex(licenseInfo, "data", &data);
        array_list *dataArr = json_object_get_array(data);
        data0 = array_list_get_idx(dataArr, 0);
        PINFO("[subscription] data[0] from str:\n---\n%s\n---\n", json_object_to_json_string_ext(data0, JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY));

        struct json_object *jstatus, *jtotalCapacity, *jremainCapacity, *jexpiredDate, *jassignedOwner, *jproductShortId, *jproductName;
        const char *status, *expiredDate, *assignedOwner, *productShortId, *productName;

        struct json_object *jlicense;
        json_object_object_get_ex(data0, "license", &jlicense);
        json_object_object_get_ex(jlicense, "status", &jstatus);
        status = json_object_get_string(jstatus);
        license->status = g_string_new(status);

        PINFO("[subscription][parse_license_with_jsonresponse] get license status %s", license->status->str);

        if (strcmp(license->status->str, "notfound") != 0)
        {
            // license exist on store
            json_object_object_get_ex(jlicense, "effectivedateend", &jexpiredDate);
            json_object_object_get_ex(jlicense, "quotaeffectiveremaining", &jremainCapacity);
            json_object_object_get_ex(jlicense, "quotaeffectivecapacityoverall", &jtotalCapacity);

            struct json_object *juser;
            json_object_object_get_ex(data0, "user", &juser);
            json_object_object_get_ex(juser, "nickname", &jassignedOwner);

            expiredDate = json_object_get_string(jexpiredDate);
            license->expiredDate = g_string_new(expiredDate);

            license->totalCapacity = json_object_get_int(jtotalCapacity);
            license->remainCapacity = json_object_get_int(jremainCapacity);

            assignedOwner = json_object_get_string(jassignedOwner);
            license->assignedOwner = g_string_new(assignedOwner);

            struct json_object *jproduct;
            json_object_object_get_ex(data0, "product", &jproduct);
            json_object_object_get_ex(jproduct, "name", &jproductName);
            json_object_object_get_ex(jproduct, "shortId", &jproductShortId);
            productName = json_object_get_string(jproductName);
            productShortId = json_object_get_string(jproductShortId);
            license->productName = g_string_new(productName);
            license->productShortId = g_string_new(productShortId);

            PINFO("[subscription] resolve productShortId %s", license->productShortId->str);

            // Adjust the productShortId base on real one
            if (strcmp(license->productShortId->str, "cash001") != 0)
            {
                // force the license to be not found.
                license->status = g_string_new("notfound");
            }

            g_free(juser);
            g_free(jproduct);
            g_free(jtotalCapacity);
            g_free(jremainCapacity);
            g_free(jexpiredDate);
            g_free(jassignedOwner);
            g_free(jproductName);
            g_free(jproductShortId);
            g_free((char *)expiredDate);
            g_free((char *)assignedOwner);
            g_free((char *)productName);
            g_free((char *)productShortId);
        }
        else
        {
            PWARN("[subscription] license not found %s, status [%s]", license->id->str, license->status->str);
            // set blank data for other properties to avoid null pointer problem
            license->assignedOwner = g_string_new("N/A");
            license->productName = g_string_new("N/A");
            license->productShortId = g_string_new("N/A");
            license->expiredDate = g_string_new("N/A");
            license->totalCapacity = 0;
            license->remainCapacity = 0;
        }

        // free resources
        g_free(data0);
        g_free(jlicense);
        g_free(jstatus);
        g_free((char *)status);
        g_free(data);
    }
    else
    {
        PWARN("[subscription] error, when parse_license_with_jsonresponse, rc is not 0");
        PWARN("[subscription] LicenseInfo from str:\n---\n%s\n---\n", json_object_to_json_string_ext(licenseInfo, JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY));
    }

    g_free(rc);
}

/**
 * License Id value entry get pressed to show or hide value
 */
static void licenseidlockbtn_clicked_cb(GtkWidget *widget, gpointer data)
{
    gboolean visible = gtk_entry_get_visibility(GTK_ENTRY(widget));

    if (visible)
    {
        gtk_entry_set_visibility(GTK_ENTRY(widget), FALSE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(widget),
                                          GTK_ENTRY_ICON_SECONDARY,
                                          "changes-allow-symbolic");
    }
    else
    {
        gtk_entry_set_visibility(GTK_ENTRY(widget), TRUE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(widget),
                                          GTK_ENTRY_ICON_SECONDARY,
                                          "changes-prevent-symbolic");
    }
}

/**
 * Show license info with builder
 */
static void display_license_info_with_builder(GtkBuilder *builder, License *license)
{
    GtkWidget *dialog, *tooltip_msg, *license_status_val, *license_overallcapcaity_val, *license_remainning_val, *assign_owner_val, *expired_date_val;
    GtkWidget *license_id_entry;

    dialog = GTK_WIDGET(gtk_builder_get_object(builder, "license_editor"));
    tooltip_msg = GTK_WIDGET(gtk_builder_get_object(builder, "tooltip_msg_label"));
    license_status_val = GTK_WIDGET(gtk_builder_get_object(builder, "license_status_val"));
    license_overallcapcaity_val = GTK_WIDGET(gtk_builder_get_object(builder, "license_overallcapcaity_val"));
    license_remainning_val = GTK_WIDGET(gtk_builder_get_object(builder, "license_remainning_val"));
    assign_owner_val = GTK_WIDGET(gtk_builder_get_object(builder, "assign_owner_val"));
    expired_date_val = GTK_WIDGET(gtk_builder_get_object(builder, "expired_date_val"));
    license_id_entry = GTK_WIDGET(gtk_builder_get_object(builder, "license_id_entry"));

    if (license->id->len > 0 /* License id exist*/)
    {
        if (strcmp(license->status->str, "notfound") == 0)
        {
            /* License not exist on store */
            gtk_label_set_text(GTK_LABEL(tooltip_msg), _("License not found or invalid on store, invalid means expired, exhausted, etc."));
            // no inuse license, the window must be uncloseable
            gtk_window_set_deletable(GTK_WINDOW(dialog), FALSE);
        }
        else
        {
            // display the license info
            gtk_label_set_text(GTK_LABEL(tooltip_msg), "");

            if (strcmp(license->status->str, "inuse") == 0)
            {
                gtk_window_set_deletable(GTK_WINDOW(dialog), TRUE);
            }
            else
            {
                // no inuse license, the window must be uncloseable
                gtk_window_set_deletable(GTK_WINDOW(dialog), FALSE);
            }
        }

        gtk_entry_set_text(GTK_ENTRY(license_id_entry), license->id->str);
        gtk_label_set_text(GTK_LABEL(license_status_val), license->status->str);
        gtk_label_set_text(GTK_LABEL(license_overallcapcaity_val), g_strdup_printf("%i", license->totalCapacity));
        gtk_label_set_text(GTK_LABEL(license_remainning_val), g_strdup_printf("%i", license->remainCapacity));
        gtk_label_set_text(GTK_LABEL(assign_owner_val), license->assignedOwner->str);
        gtk_label_set_text(GTK_LABEL(expired_date_val), license->expiredDate->str);
    }
    else
    {
        // no inuse license, the window must be uncloseable
        gtk_window_set_deletable(GTK_WINDOW(dialog), FALSE);
    }
}

/**
 * Save user input license into config file
 * * Before save, validate the license as 'inuse'
 */
static void savebtn_clicked_cb(GtkButton *button, GtkBuilder *builder)
{
    GtkWidget *dialog;
    GtkWidget *tooltip_msg;
    GtkWidget *license_id_entry;
    const gchar *license_id_entry_value;
    License *license = malloc(sizeof(*license));

    dialog = GTK_WIDGET(gtk_builder_get_object(builder, "license_editor"));
    tooltip_msg = GTK_WIDGET(gtk_builder_get_object(builder, "tooltip_msg_label"));
    gtk_label_set_text(GTK_LABEL(tooltip_msg), "");
    license_id_entry = GTK_WIDGET(gtk_builder_get_object(builder, "license_id_entry"));
    license_id_entry_value = gtk_entry_get_text(GTK_ENTRY(license_id_entry));

    PINFO("[subscription] savebtn_clicked_cb entry_text %s", license_id_entry_value);

    if (strlen(license_id_entry_value) <= 0)
    {
        // Empty string, set notice hint
        gtk_label_set_text(GTK_LABEL(tooltip_msg), _("License id should not be set as empty string."));
        // set dialog uncloseable
        gtk_window_set_deletable(GTK_WINDOW(dialog), FALSE);
    }
    else
    {
        // first, fetch the license info
        GString *licenseInfoStr = get_subscription_info_on_store(license_id_entry_value);
        license->id = g_string_new(license_id_entry_value);
        json_object *licenseInfo;

        if (licenseInfoStr->len > 0)
        {
            PINFO("[subscription][save] parsed license info ...");
            licenseInfo = json_tokener_parse(licenseInfoStr->str);
            PINFO("[subscription][save] fetched LicenseInfo:\n---\n%s\n---\n", json_object_to_json_string_ext(licenseInfo, JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY));
            parse_license_with_jsonresponse(licenseInfo, license);

            PINFO("[subscription][save] parsed license info status[%s], totalCapacity[%d], remainCapacity[%d], expiredOn[%s], user[%s]", license->status->str, license->totalCapacity, license->remainCapacity, license->expiredDate->str, license->assignedOwner->str);

            // Only license in inuse status are valid
            if (strcmp(license->status->str, "inuse") == 0)
            {
                // save to conf, first load conf object
                g_autoptr(GError) error = NULL;
                g_autoptr(GKeyFile) key_file = g_key_file_new();
                GKeyFileFlags flags;
                flags = G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS;

                gchar *license_config_filename = g_build_filename(gnc_userconfig_dir(),
                                                                  "subscription.conf", (char *)NULL);

                if (!g_key_file_load_from_file(key_file, license_config_filename, flags, &error))
                {
                    if (!g_error_matches(error, G_FILE_ERROR, G_FILE_ERROR_NOENT))
                        PWARN("Error loading key file [%s]: %s", license_config_filename, error->message);
                    exit(1);
                }

                g_key_file_set_string(key_file, "license", "licenseId", license->id->str);

                if (!g_key_file_save_to_file(key_file, license_config_filename, &error))
                {
                    PWARN("Error saving key file [%s]: %s", license_config_filename, error->message);
                    exit(1);
                }

                // refresh license info
                display_license_info_with_builder(builder, license);

                // free resources
                g_free(license_config_filename);
            }
            else
            {
                // gtk_label_set_text(GTK_LABEL(tooltip_msg), _("License id is invalid on store, e.g. expired, exhausted."));
                display_license_info_with_builder(builder, license);
            }
        }

        g_free(licenseInfoStr);
    }
    g_free(license);
}

static void networkfailure_window_close_clicked_cb(GtkButton *button, GtkBuilder *builder)
{
    PINFO("quit app");
    exit(0);
}

/**
 * Validate license on app bootstrap
 */
void gnc_licensemanagement_validate_bootstrap(GtkWindow *parent)
{
    PINFO("gnc_licensemanagement_validate_bootstrap enter ...");

    gtk_window_set_position(GTK_WINDOW(parent), GTK_WIN_POS_CENTER_ALWAYS);

    License *license = malloc(sizeof(*license));

    // first, check if have an inuse license in config
    license->id = g_string_new(init_subscription_conf());

    if (license->id->len > 0)
    {
        GString *licenseInfoStr = get_subscription_info_on_store(license->id->str);
        json_object *licenseInfo;

        if (licenseInfoStr->len > 0)
        {
            PINFO("[gnc_licensemanagement_validate_bootstrap] parsed license info ...");
            licenseInfo = json_tokener_parse(licenseInfoStr->str);
            PINFO("[gnc_licensemanagement_validate_bootstrap] fetched LicenseInfo:\n---\n%s\n---\n", json_object_to_json_string_ext(licenseInfo, JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY));
            parse_license_with_jsonresponse(licenseInfo, license);

            if (strcmp(license->status->str, "inuse") == 0)
            {
                PINFO("[gnc_licensemanagement_validate_bootstrap] have a valid licese, now request writedown quota");

                GString *postbody1 = g_string_new("{\"licenseId\":\"");
                GString *postbody2 = g_string_append(postbody1, license->id->str);
                GString *postbody3 = g_string_append(postbody2, "\",\"serverinstId\": \"BeibeiCashInst\",\"servicename\": \"Beibei Cash Inst\",\"consumes\": [1],\"requestlangorsdk\": \"c\"}");

                PINFO("[gnc_licensemanagement_validate_bootstrap] payload to writedown %s", postbody3->str);

                // now use curl to send
                CURL *curl;
                CURLcode res;
                curl_global_init(CURL_GLOBAL_ALL);

                curl = curl_easy_init();
                if (curl)
                {
                    curl_easy_setopt(curl, CURLOPT_URL, "https://store.chatopera.com/api/quotawd/write");
                    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 6);
                    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3);
                    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postbody3->str);

                    struct curl_slist *headers = NULL;
                    headers = curl_slist_append(headers, "Content-Type: application/json");
                    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

                    /* Perform the request, res gets the return code */
                    res = curl_easy_perform(curl);
                    /* Check for errors */
                    if (res != CURLE_OK)
                    {
                        const char *errormsg = curl_easy_strerror(res);
                        PWARN("curl_easy_perform() failed: %s, app exit.", errormsg);
                        // provide notify and close app
                        // Can not connect to internet?
                        g_free((char *)errormsg);
                    }

                    curl_easy_cleanup(curl);
                }

                // curl is unavailable, sys error
                curl_global_cleanup();
                g_free(postbody1);
                g_free(postbody2);
                g_free(postbody3);
            }
        }

        g_free(licenseInfoStr);
        g_free(licenseInfo);
    }

    // if license is inuse, call writedown quota API

    // At last, bring the license manage dialog for any conditions
    gnc_licensemanagement_dialog(parent);

    // free resources
    g_free(license);
}

/*  This function creates the license management dialog and presents it to
 *  the user.  The license management dialog is a singleton, so if a
 *  license management dialog already exists it will be raised to the top of
 *  the window stack instead of creating a new dialog. */
void gnc_licensemanagement_dialog(GtkWindow *parent)
{
    GtkWidget *dialog;
    GtkBuilder *builder;
    GtkWidget *save_button, *refresh_button, *license_id_entry;
    struct json_object *licenseInfo;
    License *license = malloc(sizeof(*license));

    license->id = g_string_new(init_subscription_conf());

    if (license->id->len <= 0)
    {
        PINFO("[subscription] parsed previous license id in config: [empty] ");
    }
    else
    {
        // Get license info
        PINFO("[subscription] parsed previous license id in config: [%s]", license->id->str);
        GString *licenseInfoStr = get_subscription_info_on_store(license->id->str);
        if (licenseInfoStr->len > 0)
        {
            PINFO("[subscription] parsed license info ...");
            licenseInfo = json_tokener_parse(licenseInfoStr->str);
            PINFO("[subscription] LicenseInfo from str:\n---\n%s\n---\n", json_object_to_json_string_ext(licenseInfo, JSON_C_TO_STRING_SPACED | JSON_C_TO_STRING_PRETTY));
            parse_license_with_jsonresponse(licenseInfo, license);

            PINFO("[subscription] license info status[%s], totalCapacity[%d], remainCapacity[%d], expiredOn[%s], user[%s]", license->status->str, license->totalCapacity, license->remainCapacity, license->expiredDate->str, license->assignedOwner->str);
        }
        g_free(licenseInfoStr);
    }

    /* Create the dialog */
    builder = gtk_builder_new();
    gnc_builder_add_from_file(builder, "dialog-license-management.glade", "license_editor");
    dialog = GTK_WIDGET(gtk_builder_get_object(builder, "license_editor"));

    /* window must be uncloseable by default */
    gtk_window_set_deletable(GTK_WINDOW(dialog), FALSE);

    /* Set title */
    gtk_window_set_title(GTK_WINDOW(dialog), _("License Management"));

    /* Display license info */
    display_license_info_with_builder(builder, license);

    /* Buttons */
    save_button = GTK_WIDGET(gtk_builder_get_object(builder, "save_license_id_btn"));
    g_signal_connect(save_button, "clicked", G_CALLBACK(savebtn_clicked_cb), builder);

    refresh_button = GTK_WIDGET(gtk_builder_get_object(builder, "refresh_license_id_btn"));
    g_signal_connect(refresh_button, "clicked", G_CALLBACK(savebtn_clicked_cb), builder);

    /* Set licenseId as password */
    license_id_entry = GTK_WIDGET(gtk_builder_get_object(builder, "license_id_entry"));
    g_signal_connect(license_id_entry, "icon-press", G_CALLBACK(licenseidlockbtn_clicked_cb), NULL);

    if (license->id->len > 0)
    {
        gtk_entry_set_visibility(GTK_ENTRY(license_id_entry), FALSE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(license_id_entry),
                                          GTK_ENTRY_ICON_SECONDARY,
                                          "changes-allow-symbolic");
    }
    else
    {
        gtk_entry_set_visibility(GTK_ENTRY(license_id_entry), TRUE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(license_id_entry),
                                          GTK_ENTRY_ICON_SECONDARY,
                                          "changes-prevent-symbolic");
    }
    gtk_entry_set_icon_activatable(GTK_ENTRY(license_id_entry), GTK_ENTRY_ICON_SECONDARY, TRUE);

    /* Show it */
    gtk_widget_show_all(dialog);

    g_free(license);
    g_free(licenseInfo);
}

/**
 * Check the network at startup
 * return 1, if the network is ok.
 * return 0, for an error.
 */
int gnc_licensemanagement_check_network_at_startup()
{
    // Call Api, https://store.chatopera.com/api/ping , to check network status
    CURL *curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_ALL);

    curl = curl_easy_init();
    if (curl)
    {
        curl_easy_setopt(curl, CURLOPT_URL, "https://store.chatopera.com/api/ping");
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 6);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 3);

        /* Perform the request, res gets the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if (res != CURLE_OK)
        {
            const char *errormsg = curl_easy_strerror(res);
            PWARN("curl_easy_perform() failed: %s, app exit.", errormsg);
            // provide notify and close app
            // Can not connect to internet?
            g_free((char *)errormsg);
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return 0;
        }

        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return 1;
    }

    // curl is unavailable, sys error
    curl_global_cleanup();
    return 0;
}

/**
 * A Main window to notify the network issue
 */
void gnc_licensemanagement_networkfailure_window()
{
    GtkBuilder *builder;
    static GtkWidget *notifyWindow = NULL;
    GtkWidget *content_label;
    GtkWidget *close_btn;

    builder = gtk_builder_new();
    gnc_builder_add_from_file(builder, "window-license-network-unavailabe.glade", "main");
    notifyWindow = GTK_WIDGET(gtk_builder_get_object(builder, "main"));

    gtk_window_set_decorated(GTK_WINDOW(notifyWindow), FALSE);
    gtk_window_set_skip_taskbar_hint(GTK_WINDOW(notifyWindow), TRUE);

    gtk_window_set_position(GTK_WINDOW(notifyWindow), GTK_WIN_POS_CENTER);
    gtk_window_set_type_hint(GTK_WINDOW(notifyWindow), GDK_WINDOW_TYPE_HINT_DIALOG);

    content_label = GTK_WIDGET(gtk_builder_get_object(builder, "content_label"));
    gtk_label_set_max_width_chars(GTK_LABEL(content_label), 50);

    // Buttons
    close_btn = GTK_WIDGET(gtk_builder_get_object(builder, "close_btn"));
    g_signal_connect(close_btn, "clicked", G_CALLBACK(networkfailure_window_close_clicked_cb), builder);

    // Show
    gtk_widget_show_all(notifyWindow);

    /* make sure splash is up */
    while (gtk_events_pending())
        gtk_main_iteration();
}