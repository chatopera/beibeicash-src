/*
 * dialog-licensemanagement.h -- license management dialog
 * Copyright (C) 2024 Chatopera Inc. <info@chatopera.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, contact:
 *
 * Free Software Foundation           Voice:  +1-617-542-5942
 * 51 Franklin Street, Fifth Floor    Fax:    +1-617-542-2652
 * Boston, MA  02110-1301,  USA       gnu@gnu.org
 */

#ifndef GNC_DIALOG_LICENSEMANAGEMENT_H
#define GNC_DIALOG_LICENSEMANAGEMENT_H

#include <gtk/gtk.h>

#ifdef __cplusplus
extern "C"
{
#endif

    void gnc_licensemanagement_validate_bootstrap(GtkWindow *parent);

    /** This function creates the license management dialog and presents it to
     *  the user.  The preferences dialog is a singleton, so if a
     *  preferences dialog already exists it will be raised to the top of
     *  the window stack instead of creating a new dialog. */
    void gnc_licensemanagement_dialog(GtkWindow *parent);

    /**
     * Use to check network connection to store service, if not available, just popup a notify
     * dialog to close the app
     */
    int gnc_licensemanagement_check_network_at_startup(void);

    /**
     * Display the notify window for network issue
     */
    void gnc_licensemanagement_networkfailure_window(void);

#ifdef __cplusplus
}
#endif

#endif
